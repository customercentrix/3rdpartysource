/**
 * guice-persist's Java Persistence API (JPA) support.
 */
package com.google.inject.persist.jpa;