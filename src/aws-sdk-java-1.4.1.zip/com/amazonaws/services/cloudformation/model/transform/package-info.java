
/**
 * Marhsalling for the various types represented by AmazonCloudFormation.
 */
 package com.amazonaws.services.cloudformation.model.transform;
        