
/**
 * Classes modeling the various types represented by AmazonAutoScaling.
 */
 package com.amazonaws.services.autoscaling.model;
        