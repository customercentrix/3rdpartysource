
/**
 * Classes modeling the various types represented by AmazonCloudFront.
 */
 package com.amazonaws.services.cloudfront.model;
        